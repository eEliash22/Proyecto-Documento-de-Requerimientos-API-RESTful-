package gt.umg.tienda;
import org.junit.jupiter.api.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.MediaType;
import gt.umg.tienda.entity.*;
import gt.umg.tienda.repository.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
@SpringBootTest @AutoConfigureMockMvc @Transactional
class FlujoTiendaTest {
 @Autowired MockMvc mvc;@Autowired ProductoRepository productos;@Autowired PedidoRepository pedidos;@Autowired ObjectMapper json;
 Long id;MockHttpSession sesion;
 @BeforeEach void preparar(){id=productos.saveAndFlush(new Producto("CAM","Cámara",new BigDecimal("100.00"),5)).getId();sesion=new MockHttpSession();}
 @Test void catalogoPublico()throws Exception{mvc.perform(get("/api/productos")).andExpect(status().isOk()).andExpect(jsonPath("$[0].codigo").value("CAM"));}
 @Test void productoInexistente()throws Exception{mvc.perform(get("/api/productos/999999")).andExpect(status().isNotFound());}
 @Test void escrituraRequiereAdmin()throws Exception{mvc.perform(post("/api/productos").with(csrf()).contentType(MediaType.APPLICATION_JSON).content(datos())).andExpect(status().is3xxRedirection());}
 @Test void escrituraRequiereCsrf()throws Exception{mvc.perform(post("/api/productos").with(user("admin").roles("ADMIN")).contentType(MediaType.APPLICATION_JSON).content(datos())).andExpect(status().isForbidden());}
 @Test void crudAdmin()throws Exception{
 var r=mvc.perform(post("/api/productos").with(user("admin").roles("ADMIN")).with(csrf()).contentType(MediaType.APPLICATION_JSON).content(datos())).andExpect(status().isCreated()).andReturn();
 long nuevo=json.readTree(r.getResponse().getContentAsString()).get("id").asLong();
 mvc.perform(put("/api/productos/"+nuevo).with(user("admin").roles("ADMIN")).with(csrf()).contentType(MediaType.APPLICATION_JSON).content(datos().replace("Prueba","Cambio"))).andExpect(status().isOk()).andExpect(jsonPath("$.nombre").value("Cambio"));
 mvc.perform(delete("/api/productos/"+nuevo).with(user("admin").roles("ADMIN")).with(csrf())).andExpect(status().isNoContent());
 }
 @Test void rechazaPrecioNegativo()throws Exception{mvc.perform(post("/api/productos").with(user("admin").roles("ADMIN")).with(csrf()).contentType(MediaType.APPLICATION_JSON).content(datos().replace("10.00","-1.00"))).andExpect(status().isBadRequest());}
 @Test void agregaAcumulaYCambia()throws Exception{
 agregar(2);agregar(1);
 var r=mvc.perform(get("/api/carrito").session(sesion)).andExpect(jsonPath("$.total").value(300.0)).andReturn();
 long linea=json.readTree(r.getResponse().getContentAsString()).at("/lineas/0/id").asLong();
 mvc.perform(put("/api/carrito/items/"+linea).session(sesion).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"cantidad\":1}")).andExpect(status().isOk()).andExpect(jsonPath("$.total").value(100.0));
 mvc.perform(delete("/api/carrito/items/"+linea).session(sesion).with(csrf())).andExpect(status().isOk());
 mvc.perform(get("/api/carrito").session(sesion)).andExpect(jsonPath("$.lineas").isEmpty());
 }
 @Test void rechazaSinStock()throws Exception{mvc.perform(post("/api/carrito/items").session(sesion).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"productoId\":"+id+",\"cantidad\":6}")).andExpect(status().isBadRequest());}
 @Test void rechazaCantidadCero()throws Exception{mvc.perform(post("/api/carrito/items").session(sesion).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"productoId\":"+id+",\"cantidad\":0}")).andExpect(status().isBadRequest());}
 @Test void aislaSesionesYProtegeLineas()throws Exception{
 agregar(1);var r=mvc.perform(get("/api/carrito").session(sesion)).andReturn();long linea=json.readTree(r.getResponse().getContentAsString()).at("/lineas/0/id").asLong();
 mvc.perform(get("/api/carrito").session(new MockHttpSession())).andExpect(jsonPath("$.lineas").isEmpty());
 mvc.perform(delete("/api/carrito/items/"+linea).session(new MockHttpSession()).with(csrf())).andExpect(status().isNotFound());}
 @Test void vaciaCarrito()throws Exception{agregar(1);mvc.perform(delete("/api/carrito").session(sesion).with(csrf())).andExpect(status().isOk());mvc.perform(get("/api/carrito").session(sesion)).andExpect(jsonPath("$.lineas").isEmpty());}
 @Test void compraDescuentaYGuarda()throws Exception{agregar(2);mvc.perform(post("/api/pedidos").session(sesion).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"metodo\":\"PAYPAL\"}")).andExpect(status().isCreated()).andExpect(jsonPath("$.total").value(200.0)).andExpect(jsonPath("$.referencia").value(org.hamcrest.Matchers.startsWith("DEMO-PAYPAL-")));Assertions.assertEquals(3,productos.findById(id).orElseThrow().getStock());mvc.perform(get("/api/carrito").session(sesion)).andExpect(jsonPath("$.lineas").isEmpty());mvc.perform(get("/api/pedidos").session(sesion)).andExpect(jsonPath("$[0].detalles[0].cantidad").value(2));}
 @Test void compraVaciaNoCreaPedido()throws Exception{mvc.perform(post("/api/pedidos").session(sesion).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"metodo\":\"EFECTIVO\"}")).andExpect(status().isBadRequest());Assertions.assertEquals(0,pedidos.count());}
 private void agregar(int n)throws Exception{mvc.perform(post("/api/carrito/items").session(sesion).with(csrf()).contentType(MediaType.APPLICATION_JSON).content("{\"productoId\":"+id+",\"cantidad\":"+n+"}")).andExpect(status().isOk());}
 private String datos(){return "{\"codigo\":\"P2\",\"nombre\":\"Prueba\",\"precio\":10.00,\"stock\":3}";}
}
