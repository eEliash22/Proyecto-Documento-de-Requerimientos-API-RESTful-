package gt.umg.tienda.controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.core.Authentication;
import java.util.Map;
@RestController
public class SesionController {
 @GetMapping("/api/csrf") public Map<String,String> csrf(CsrfToken token){return Map.of("header",token.getHeaderName(),"token",token.getToken());}
 @GetMapping("/api/sesion") public Map<String,Boolean> sesion(Authentication a){return Map.of("admin",a!=null&&a.getAuthorities().stream().anyMatch(r->r.getAuthority().equals("ROLE_ADMIN")));}
}
