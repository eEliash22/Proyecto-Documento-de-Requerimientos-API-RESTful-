package gt.umg.tienda.config;
import gt.umg.tienda.patterns.factory.*;
import org.springframework.boot.*;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
@Component @Profile("permisos")
public class DemoPermisos implements CommandLineRunner {
 public void run(String...args)throws Exception{
 String url=System.getenv().getOrDefault("DB_URL","jdbc:mariadb://127.0.0.1:3306/carrito_java");
 ConexionCreator[] creadores={new LecturaCreator(url,"tienda_lectura",System.getenv().getOrDefault("LECTURA_PASSWORD","LecturaLocal_2026!")),new EscrituraCreator(url,"tienda_escritura",System.getenv().getOrDefault("ESCRITURA_PASSWORD","EscrituraLocal_2026!")),new LecturaEscrituraCreator(url,"tienda_rw",System.getenv().getOrDefault("RW_PASSWORD","RwLocal_2026!"))};
 for(var creador:creadores)System.out.printf("FACTORY %s usuario=%s lectura=%s escritura=%s%n",creador.getClass().getSimpleName(),creador.usuarioEfectivo(),creador.puedeLeer(),creador.puedeEscribir());
 }
}
