package gt.umg.tienda.config;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.http.HttpMethod;
@Configuration
public class Seguridad {
 @Bean UserDetailsService usuarios(@Value("${app.admin.password}") String password){return new InMemoryUserDetailsManager(User.withUsername("admin").password(new BCryptPasswordEncoder().encode(password)).roles("ADMIN").build());}
 @Bean org.springframework.security.crypto.password.PasswordEncoder encoder(){return new BCryptPasswordEncoder();}
 @Bean SecurityFilterChain filtros(HttpSecurity h)throws Exception{
 h.authorizeHttpRequests(a->a.requestMatchers(HttpMethod.GET,"/api/productos","/api/productos/**").permitAll().requestMatchers("/api/productos","/api/productos/**").hasRole("ADMIN").anyRequest().permitAll())
 .formLogin(f->f.defaultSuccessUrl("/",true).permitAll()).logout(l->l.logoutSuccessUrl("/").permitAll());
 return h.build();
 }
}
