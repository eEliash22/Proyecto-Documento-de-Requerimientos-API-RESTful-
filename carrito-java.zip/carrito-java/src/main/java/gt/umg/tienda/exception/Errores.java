package gt.umg.tienda.exception;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.http.*;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import java.util.Map;
@RestControllerAdvice
public class Errores {
 @ExceptionHandler(NoEncontrado.class) ResponseEntity<?> noEncontrado(NoEncontrado e){return respuesta(404,e.getMessage());}
 @ExceptionHandler(IllegalArgumentException.class) ResponseEntity<?> invalido(IllegalArgumentException e){return respuesta(400,e.getMessage());}
 @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<?> validacion(MethodArgumentNotValidException e){return respuesta(400,"Datos inválidos: "+e.getBindingResult().getFieldErrors().stream().map(x->x.getField()+" "+x.getDefaultMessage()).toList());}
 @ExceptionHandler(HttpMessageNotReadableException.class) ResponseEntity<?> json(){return respuesta(400,"JSON inválido");}
 @ExceptionHandler(DataIntegrityViolationException.class) ResponseEntity<?> conflicto(){return respuesta(409,"Código duplicado o producto presente en un carrito; quite las líneas antes de eliminarlo.");}
 private ResponseEntity<?> respuesta(int status,String mensaje){return ResponseEntity.status(status).body(Map.of("mensaje",mensaje));}
}
