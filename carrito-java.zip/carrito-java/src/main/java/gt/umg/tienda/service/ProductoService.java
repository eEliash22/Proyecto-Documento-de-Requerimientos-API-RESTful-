package gt.umg.tienda.service;
import gt.umg.tienda.entity.Producto;
import gt.umg.tienda.dto.Dto.*;
import gt.umg.tienda.exception.NoEncontrado;
import gt.umg.tienda.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
@Service @Transactional
public class ProductoService {
 private final ProductoRepository repo;
 public ProductoService(ProductoRepository repo){this.repo=repo;}
 public List<ProductoSalida> listar(){return repo.findAll().stream().map(this::salida).toList();}
 public ProductoSalida consultar(Long id){return salida(buscar(id));}
 public ProductoSalida crear(ProductoEntrada d){return salida(repo.save(new Producto(d.codigo().trim(),d.nombre().trim(),d.precio(),d.stock())));}
 public ProductoSalida actualizar(Long id,ProductoEntrada d){Producto p=buscar(id);p.actualizar(d.codigo().trim(),d.nombre().trim(),d.precio(),d.stock());return salida(p);}
 public void eliminar(Long id){repo.delete(buscar(id));repo.flush();}
 private Producto buscar(Long id){return repo.findById(id).orElseThrow(()->new NoEncontrado("Producto no encontrado"));}
 private ProductoSalida salida(Producto p){return new ProductoSalida(p.getId(),p.getCodigo(),p.getNombre(),p.getPrecio(),p.getStock());}
}
