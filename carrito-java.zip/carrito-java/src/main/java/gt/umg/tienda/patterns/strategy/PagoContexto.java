package gt.umg.tienda.patterns.strategy;
import org.springframework.stereotype.Component;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.math.BigDecimal;
@Component
public class PagoContexto {
 private final Map<String,PagoStrategy> estrategias;
 public PagoContexto(List<PagoStrategy> estrategias){this.estrategias=estrategias.stream().collect(Collectors.toMap(PagoStrategy::metodo,Function.identity()));}
 public String pagar(String metodo,BigDecimal total){var estrategia=estrategias.get(metodo);if(estrategia==null)throw new IllegalArgumentException("Método de pago no admitido");return estrategia.procesar(total);}
}
