package gt.umg.tienda.controller;
import gt.umg.tienda.dto.Dto.*;
import gt.umg.tienda.service.ProductoService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/productos")
public class ProductoController {
 private final ProductoService service;public ProductoController(ProductoService s){service=s;}
 @GetMapping public List<ProductoSalida> listar(){return service.listar();}
 @GetMapping("/{id}") public ProductoSalida ver(@PathVariable Long id){return service.consultar(id);}
 @PostMapping @ResponseStatus(org.springframework.http.HttpStatus.CREATED) public ProductoSalida crear(@Valid @RequestBody ProductoEntrada d){return service.crear(d);}
 @PutMapping("/{id}") public ProductoSalida actualizar(@PathVariable Long id,@Valid @RequestBody ProductoEntrada d){return service.actualizar(id,d);}
 @DeleteMapping("/{id}") @ResponseStatus(org.springframework.http.HttpStatus.NO_CONTENT) public void eliminar(@PathVariable Long id){service.eliminar(id);}
}
