-- Ejecutar como root después de 01_base.sql. Cuentas exclusivas para esta práctica.
CREATE USER IF NOT EXISTS 'tienda_lectura'@'localhost' IDENTIFIED BY 'LecturaLocal_2026!';
CREATE USER IF NOT EXISTS 'tienda_escritura'@'localhost' IDENTIFIED BY 'EscrituraLocal_2026!';
CREATE USER IF NOT EXISTS 'tienda_rw'@'localhost' IDENTIFIED BY 'RwLocal_2026!';
GRANT SELECT ON carrito_java.* TO 'tienda_lectura'@'localhost';
GRANT INSERT,UPDATE,DELETE ON carrito_java.* TO 'tienda_escritura'@'localhost';
GRANT SELECT,INSERT,UPDATE,DELETE ON carrito_java.* TO 'tienda_rw'@'localhost';
-- Los GRANT se aplican inmediatamente. CREATE USER IF NOT EXISTS no cambia claves previas.
