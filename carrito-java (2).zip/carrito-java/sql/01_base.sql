-- Importar en phpMyAdmin como root. No borra bases existentes.
CREATE DATABASE IF NOT EXISTS carrito_java CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE carrito_java;
CREATE TABLE IF NOT EXISTS producto (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 codigo VARCHAR(40) NOT NULL UNIQUE,nombre VARCHAR(150) NOT NULL,
 precio DECIMAL(12,2) NOT NULL, stock INT NOT NULL,
 CHECK(precio>0), CHECK(stock>=0)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS linea_carrito (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,sesion VARCHAR(100) NOT NULL,
 producto_id BIGINT NOT NULL,cantidad INT NOT NULL,
 UNIQUE(sesion,producto_id),FOREIGN KEY(producto_id) REFERENCES producto(id), CHECK(cantidad>0)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS pedido (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,sesion VARCHAR(100) NOT NULL,
 metodo VARCHAR(30) NOT NULL,referencia VARCHAR(80) NOT NULL,total DECIMAL(12,2) NOT NULL,fecha DATETIME(6) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS detalle_pedido (
 id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,pedido_id BIGINT NOT NULL,
 nombre VARCHAR(150) NOT NULL,precio DECIMAL(12,2) NOT NULL,cantidad INT NOT NULL,
 FOREIGN KEY(pedido_id) REFERENCES pedido(id)
) ENGINE=InnoDB;
INSERT INTO producto(codigo,nombre,precio,stock)
SELECT '3DcAM01','FinePix Pro2 3D Camera',671.21,20 WHERE NOT EXISTS(SELECT 1 FROM producto WHERE codigo='3DcAM01');
INSERT INTO producto(codigo,nombre,precio,stock)
SELECT 'USB02','EXP Portable Hard Drive',215.10,20 WHERE NOT EXISTS(SELECT 1 FROM producto WHERE codigo='USB02');
INSERT INTO producto(codigo,nombre,precio,stock)
SELECT 'wristWear03','Luxury Ultra thin Wrist Watch',2121.86,15 WHERE NOT EXISTS(SELECT 1 FROM producto WHERE codigo='wristWear03');
INSERT INTO producto(codigo,nombre,precio,stock)
SELECT 'LPN45','XP 1155 Intel Core Laptop',10232.35,10 WHERE NOT EXISTS(SELECT 1 FROM producto WHERE codigo='LPN45');
-- Usuarios de laboratorio: cambiar claves en SQL y configuración si se necesitan otras.
CREATE USER IF NOT EXISTS 'tienda_app'@'localhost' IDENTIFIED BY 'TiendaLocal_2026!';
GRANT SELECT,INSERT,UPDATE,DELETE ON carrito_java.* TO 'tienda_app'@'localhost';
