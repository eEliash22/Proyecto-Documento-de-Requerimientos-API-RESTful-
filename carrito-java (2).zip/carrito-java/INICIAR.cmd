@echo off
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (echo Instala JDK 17 y configura JAVA_HOME. & pause & exit /b 1)
if exist target\carrito-java-1.0.0.jar (java -jar target\carrito-java-1.0.0.jar) else (echo Primero abre pom.xml en IntelliJ y ejecuta Maven package. & pause)
