package gt.umg.tienda;

import gt.umg.tienda.entity.Producto;
import gt.umg.tienda.exception.NoEncontrado;
import gt.umg.tienda.patterns.strategy.*;
import gt.umg.tienda.repository.ProductoRepository;
import gt.umg.tienda.service.ProductoService;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UnidadTest {

 @Test
 void stockNoPuedeSerNegativo() {
  var p = new Producto(
          "A",
          "A",
          BigDecimal.TEN,
          1
  );

  assertThrows(
          IllegalArgumentException.class,
          () -> p.descontar(2)
  );

  assertEquals(1, p.getStock());
 }

 @Test
 void servicioReportaNoEncontrado() {
  var repo = mock(ProductoRepository.class);

  when(repo.findById(99L))
          .thenReturn(Optional.empty());

  assertThrows(
          NoEncontrado.class,
          () -> new ProductoService(repo).consultar(99L)
  );

  verify(repo).findById(99L);
 }

 @Test
 void estrategiasSonIntercambiables() {
  var contexto = new PagoContexto(
          List.of(
                  new PagoEfectivo(),
                  new PagoCredito(),
                  new PagoDebito(),
                  new PagoPaypal()
          )
  );

  for (String m : List.of(
          "EFECTIVO",
          "CREDITO",
          "DEBITO",
          "PAYPAL"
  )) {
   assertTrue(
           contexto.pagar(m, BigDecimal.TEN)
                   .startsWith("DEMO-" + m + "-")
   );
  }
 }

 @Test
 void metodoNoExiste() {
  var contexto = new PagoContexto(List.of());

  assertThrows(
          IllegalArgumentException.class,
          () -> contexto.pagar("OTRO", BigDecimal.TEN)
  );
 }

 @Test
 void contextoDelegaConMockito() {
  var estrategia = mock(PagoStrategy.class);

  when(estrategia.metodo())
          .thenReturn("PRUEBA");

  when(estrategia.procesar(BigDecimal.TEN))
          .thenReturn("OK");

  assertEquals(
          "OK",
          new PagoContexto(List.of(estrategia))
                  .pagar("PRUEBA", BigDecimal.TEN)
  );

  verify(estrategia).procesar(BigDecimal.TEN);
 }
}