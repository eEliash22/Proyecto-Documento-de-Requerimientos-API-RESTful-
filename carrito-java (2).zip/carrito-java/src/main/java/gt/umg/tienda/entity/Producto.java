package gt.umg.tienda.entity;
import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity @Table(name="producto")
public class Producto {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,unique=true,length=40) private String codigo;
 @Column(nullable=false,length=150) private String nombre;
 @Column(nullable=false,precision=12,scale=2) private BigDecimal precio;
 @Column(nullable=false) private int stock;
 protected Producto() {}
 public Producto(String codigo,String nombre,BigDecimal precio,int stock){actualizar(codigo,nombre,precio,stock);}
 public void actualizar(String codigo,String nombre,BigDecimal precio,int stock){this.codigo=codigo;this.nombre=nombre;this.precio=precio;this.stock=stock;}
 public void descontar(int cantidad){if(cantidad<1||stock<cantidad)throw new IllegalArgumentException("Stock insuficiente para "+nombre);stock-=cantidad;}
 public Long getId(){return id;} public String getCodigo(){return codigo;} public String getNombre(){return nombre;}
 public BigDecimal getPrecio(){return precio;} public int getStock(){return stock;}
}
