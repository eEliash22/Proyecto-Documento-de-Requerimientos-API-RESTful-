package gt.umg.tienda.entity;
import jakarta.persistence.*;
import java.math.BigDecimal;
@Entity @Table(name="detalle_pedido")
public class DetallePedido {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false,fetch=FetchType.LAZY) private Pedido pedido;
 @Column(nullable=false,length=150) private String nombre;
 @Column(nullable=false,precision=12,scale=2) private BigDecimal precio;
 @Column(nullable=false) private int cantidad;
 protected DetallePedido(){}
 public DetallePedido(Pedido pedido,Producto p,int cantidad){this.pedido=pedido;this.nombre=p.getNombre();this.precio=p.getPrecio();this.cantidad=cantidad;}
 public String getNombre(){return nombre;} public BigDecimal getPrecio(){return precio;} public int getCantidad(){return cantidad;}
}
