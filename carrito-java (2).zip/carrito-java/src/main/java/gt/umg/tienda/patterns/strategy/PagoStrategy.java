package gt.umg.tienda.patterns.strategy;
import java.math.BigDecimal;
public interface PagoStrategy {String metodo();String procesar(BigDecimal total);}
