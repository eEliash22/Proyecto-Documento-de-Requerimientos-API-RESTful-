package gt.umg.tienda.patterns.factory;
import java.sql.*;
public class LecturaEscrituraCreator extends ConexionCreator {
 private final String url,usuario,password;
 public LecturaEscrituraCreator(String url,String usuario,String password){this.url=url;this.usuario=usuario;this.password=password;}
 @Override protected Connection crearConexion()throws SQLException{return DriverManager.getConnection(url,usuario,password);}
}
