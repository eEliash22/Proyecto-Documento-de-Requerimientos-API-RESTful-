package gt.umg.tienda.entity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
@Entity @Table(name="pedido")
public class Pedido {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,length=100) private String sesion;
 @Column(nullable=false,length=30) private String metodo;
 @Column(nullable=false,length=80) private String referencia;
 @Column(nullable=false,precision=12,scale=2) private BigDecimal total;
 @Column(nullable=false) private LocalDateTime fecha;
 @OneToMany(mappedBy="pedido",cascade=CascadeType.ALL) private List<DetallePedido> detalles=new ArrayList<>();
 protected Pedido(){}
 public Pedido(String sesion,String metodo,String referencia,BigDecimal total){this.sesion=sesion;this.metodo=metodo;this.referencia=referencia;this.total=total;this.fecha=LocalDateTime.now();}
 public void agregar(Producto p,int cantidad){detalles.add(new DetallePedido(this,p,cantidad));}
 public Long getId(){return id;} public String getMetodo(){return metodo;} public String getReferencia(){return referencia;}
 public BigDecimal getTotal(){return total;} public LocalDateTime getFecha(){return fecha;} public List<DetallePedido> getDetalles(){return Collections.unmodifiableList(detalles);}
}
