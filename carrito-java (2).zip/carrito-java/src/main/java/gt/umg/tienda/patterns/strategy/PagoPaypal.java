package gt.umg.tienda.patterns.strategy;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.util.UUID;
/** Simulador académico: no llama pasarelas ni realiza cobros reales. */
@Component
public class PagoPaypal implements PagoStrategy {
 public String metodo(){return "PAYPAL";}
 public String procesar(BigDecimal total){if(total==null||total.signum()<=0)throw new IllegalArgumentException("Total inválido");return "DEMO-PAYPAL-"+UUID.randomUUID();}
}
