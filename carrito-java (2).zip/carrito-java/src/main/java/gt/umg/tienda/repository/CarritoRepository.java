package gt.umg.tienda.repository;
import gt.umg.tienda.entity.LineaCarrito;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;
import java.util.*;
public interface CarritoRepository extends JpaRepository<LineaCarrito,Long> {
 List<LineaCarrito> findBySesionOrderById(String sesion);
 @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select l from LineaCarrito l where l.sesion=:sesion order by l.id")
 List<LineaCarrito> bloquearSesion(@Param("sesion") String sesion);
 Optional<LineaCarrito> findBySesionAndProductoId(String sesion,Long productoId);
 Optional<LineaCarrito> findByIdAndSesion(Long id,String sesion);
 void deleteBySesion(String sesion);
}
