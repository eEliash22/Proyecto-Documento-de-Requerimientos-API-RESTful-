package gt.umg.tienda.repository;
import gt.umg.tienda.entity.Producto;
import org.springframework.data.jpa.repository.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.repository.query.Param;
import java.util.Optional;
public interface ProductoRepository extends JpaRepository<Producto,Long> {
 @Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select p from Producto p where p.id=:id")
 Optional<Producto> bloquear(@Param("id") Long id);
}
