package gt.umg.tienda.dto;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
public final class Dto {
 private Dto(){}
 public record ProductoEntrada(@NotBlank @Size(max=40) String codigo,@NotBlank @Size(max=150) String nombre,
 @NotNull @DecimalMin("0.01") @Digits(integer=10,fraction=2) BigDecimal precio,@Min(0) int stock){}
 public record ProductoSalida(Long id,String codigo,String nombre,BigDecimal precio,int stock){}
 public record Agregar(@NotNull @Positive Long productoId,@Min(1) @Max(999) int cantidad){}
 public record Cantidad(@Min(1) @Max(999) int cantidad){}
 public record Linea(Long id,Long productoId,String nombre,BigDecimal precio,int cantidad,BigDecimal subtotal){}
 public record Carrito(List<Linea> lineas,BigDecimal total){}
 public record Pago(@NotBlank String metodo){}
 public record Detalle(String nombre,BigDecimal precio,int cantidad){}
 public record Orden(Long id,String metodo,String referencia,BigDecimal total,LocalDateTime fecha,List<Detalle> detalles){}
}
