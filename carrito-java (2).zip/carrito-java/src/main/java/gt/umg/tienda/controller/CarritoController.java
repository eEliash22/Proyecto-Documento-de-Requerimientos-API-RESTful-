package gt.umg.tienda.controller;
import gt.umg.tienda.dto.Dto.*;
import gt.umg.tienda.service.CarritoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/carrito")
public class CarritoController {
 private final CarritoService service;public CarritoController(CarritoService s){service=s;
 }
 @GetMapping public Carrito ver(HttpSession s){return service.ver(s.getId());
 }
 @PostMapping("/items") public Carrito agregar(HttpSession s,@Valid @RequestBody Agregar d){return service.agregar(s.getId(),d);
 }
 @PutMapping("/items/{id}") public Carrito cambiar(HttpSession s,@PathVariable Long id,@Valid @RequestBody Cantidad d){return service.cambiar(s.getId(),id,d.cantidad());
 }
 @DeleteMapping("/items/{id}") public void quitar(HttpSession s,@PathVariable Long id){service.quitar(s.getId(),id);
 }
 @DeleteMapping public void vaciar(HttpSession s){service.vaciar(s.getId());}
}
