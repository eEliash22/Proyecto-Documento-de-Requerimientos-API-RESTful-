package gt.umg.tienda.exception;
public class NoEncontrado extends RuntimeException
{
    public NoEncontrado(String mensaje){super(mensaje);
    }
}
