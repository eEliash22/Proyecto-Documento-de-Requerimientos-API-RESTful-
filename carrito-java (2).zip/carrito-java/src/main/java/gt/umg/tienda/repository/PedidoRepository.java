package gt.umg.tienda.repository;
import gt.umg.tienda.entity.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface PedidoRepository extends JpaRepository<Pedido,Long> {List<Pedido> findBySesionOrderByIdDesc(String sesion);}
