package gt.umg.tienda.controller;
import gt.umg.tienda.dto.Dto.*;
import gt.umg.tienda.service.PedidoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/pedidos")
public class PedidoController {
 private final PedidoService service;public PedidoController(PedidoService s){service=s;
 }
 @GetMapping
 public List<Orden> listar(HttpSession s)
 {return service.listar(s.getId());
 }
 @PostMapping @ResponseStatus(org.springframework.http.HttpStatus.CREATED)
 public Orden comprar(HttpSession s,@Valid @RequestBody Pago d)
 {return service.comprar(s.getId(),d.metodo());
 }
}
