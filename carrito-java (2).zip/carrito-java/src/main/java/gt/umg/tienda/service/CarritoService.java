package gt.umg.tienda.service;

import gt.umg.tienda.dto.Dto.*;
import gt.umg.tienda.entity.*;
import gt.umg.tienda.exception.NoEncontrado;
import gt.umg.tienda.repository.*;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@Transactional
public class CarritoService {

 private final CarritoRepository carrito;
 private final ProductoRepository productos;

 public CarritoService(CarritoRepository c, ProductoRepository p) {
  carrito = c;
  productos = p;
 }

 public Carrito ver(String sesion) {
  var lineas = carrito.findBySesionOrderById(sesion)
          .stream()
          .map(l -> new Linea(
                  l.getId(),
                  l.getProducto().getId(),
                  l.getProducto().getNombre(),
                  l.getProducto().getPrecio(),
                  l.getCantidad(),
                  l.getProducto().getPrecio().multiply(
                          BigDecimal.valueOf(l.getCantidad())
                  )
          ))
          .toList();

  return new Carrito(
          lineas,
          lineas.stream()
                  .map(Linea::subtotal)
                  .reduce(BigDecimal.ZERO, BigDecimal::add)
  );
 }

 public Carrito agregar(String sesion, Agregar d) {
  Producto p = productos.bloquear(d.productoId())
          .orElseThrow(
                  () -> new NoEncontrado("Producto no encontrado")
          );

  var linea = carrito.findBySesionAndProductoId(sesion, p.getId())
          .orElse(
                  new LineaCarrito(sesion, p, 0)
          );

  int cantidad = linea.getCantidad() + d.cantidad();

  validar(p, cantidad);

  linea.setCantidad(cantidad);
  carrito.saveAndFlush(linea);

  return ver(sesion);
 }

 public Carrito cambiar(String sesion, Long id, int cantidad) {
  var l = carrito.findByIdAndSesion(id, sesion)
          .orElseThrow(
                  () -> new NoEncontrado("Línea no encontrada")
          );

  validar(l.getProducto(), cantidad);

  l.setCantidad(cantidad);

  return ver(sesion);
 }

 public void quitar(String sesion, Long id) {
  carrito.delete(
          carrito.findByIdAndSesion(id, sesion)
                  .orElseThrow(
                          () -> new NoEncontrado("Línea no encontrada")
                  )
  );
 }

 public void vaciar(String sesion) {
  carrito.deleteBySesion(sesion);
 }

 private void validar(Producto p, int cantidad) {
  if (cantidad < 1 || cantidad > 999 || cantidad > p.getStock()) {
   throw new IllegalArgumentException(
           "Cantidad inválida o stock insuficiente para "
                   + p.getNombre()
   );
  }
 }
}