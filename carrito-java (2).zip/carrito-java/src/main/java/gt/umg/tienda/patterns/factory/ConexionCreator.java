package gt.umg.tienda.patterns.factory;
import java.sql.*;
public abstract class ConexionCreator {
 protected abstract Connection crearConexion() throws SQLException;
 public final String usuarioEfectivo() throws SQLException {
  try(Connection c=crearConexion();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT CURRENT_USER()")){r.next();return r.getString(1);}
 }
 public final boolean puedeLeer() throws SQLException {
  try(Connection c=crearConexion();Statement s=c.createStatement()){s.executeQuery("SELECT id FROM producto LIMIT 1").close();return true;}
  catch(SQLException e){if("42000".equals(e.getSQLState()))return false;throw e;}
 }
 public final boolean puedeEscribir() throws SQLException {
  // WHERE 1=0 comprueba privilegios UPDATE sin modificar productos.
  try(Connection c=crearConexion();Statement s=c.createStatement()){s.executeUpdate("UPDATE producto SET nombre='Prueba permisos' WHERE 1=0");return true;}
  catch(SQLException e){if("42000".equals(e.getSQLState()))return false;throw e;}
 }
}
