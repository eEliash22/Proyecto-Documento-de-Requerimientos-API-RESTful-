package gt.umg.tienda.entity;
import jakarta.persistence.*;
@Entity @Table(name="linea_carrito",uniqueConstraints=@UniqueConstraint(columnNames={"sesion","producto_id"}))
public class LineaCarrito {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,length=100) private String sesion;
 @ManyToOne(optional=false,fetch=FetchType.LAZY) @JoinColumn(name="producto_id") private Producto producto;
 @Column(nullable=false) private int cantidad;
 protected LineaCarrito(){}
 public LineaCarrito(String sesion,Producto producto,int cantidad){this.sesion=sesion;this.producto=producto;this.cantidad=cantidad;}
 public Long getId(){return id;} public Producto getProducto(){return producto;} public int getCantidad(){return cantidad;}
 public void setCantidad(int cantidad){this.cantidad=cantidad;}
}
