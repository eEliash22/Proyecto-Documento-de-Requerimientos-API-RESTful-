package gt.umg.tienda.service;

import gt.umg.tienda.dto.Dto.*;
import gt.umg.tienda.entity.*;
import gt.umg.tienda.exception.NoEncontrado;
import gt.umg.tienda.patterns.strategy.PagoContexto;
import gt.umg.tienda.repository.*;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

@Service
@Transactional
public class PedidoService {

 private final PedidoRepository pedidos;
 private final CarritoRepository carrito;
 private final ProductoRepository productos;
 private final PagoContexto pagos;

 public PedidoService(
         PedidoRepository p,
         CarritoRepository c,
         ProductoRepository r,
         PagoContexto pagos
 ) {
  pedidos = p;
  carrito = c;
  productos = r;
  this.pagos = pagos;
 }

 public Orden comprar(String sesion, String metodo) {
  var lineas = carrito.bloquearSesion(sesion);

  if (lineas.isEmpty()) {
   throw new IllegalArgumentException("El carrito está vacío");
  }

  // Orden estable de bloqueos para reducir interbloqueos
  // entre compras concurrentes.
  lineas.sort(
          Comparator.comparing(l -> l.getProducto().getId())
  );

  BigDecimal total = BigDecimal.ZERO;

  for (var l : lineas) {
   var p = productos.bloquear(l.getProducto().getId())
           .orElseThrow(
                   () -> new NoEncontrado("Producto no encontrado")
           );

   p.descontar(l.getCantidad());

   total = total.add(
           p.getPrecio().multiply(
                   BigDecimal.valueOf(l.getCantidad())
           )
   );
  }

  String referencia = pagos.pagar(metodo, total);

  Pedido pedido = new Pedido(
          sesion,
          metodo,
          referencia,
          total
  );

  lineas.forEach(
          l -> pedido.agregar(
                  l.getProducto(),
                  l.getCantidad()
          )
  );

  pedidos.saveAndFlush(pedido);
  carrito.deleteAll(lineas);

  return salida(pedido);
 }

 public List<Orden> listar(String sesion) {
  return pedidos.findBySesionOrderByIdDesc(sesion)
          .stream()
          .map(this::salida)
          .toList();
 }

 private Orden salida(Pedido p) {
  return new Orden(
          p.getId(),
          p.getMetodo(),
          p.getReferencia(),
          p.getTotal(),
          p.getFecha(),
          p.getDetalles()
                  .stream()
                  .map(d -> new Detalle(
                          d.getNombre(),
                          d.getPrecio(),
                          d.getCantidad()
                  ))
                  .toList()
  );
 }
}